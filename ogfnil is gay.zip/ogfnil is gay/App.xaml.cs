﻿// Decompiled with JetBrains decompiler
// Type: og.App
// Assembly: OG, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C45CBA76-03EF-9BAF-765B-D5EE920F1372
// Assembly location: C:\Users\admin\Downloads\OG_FN_IL_-_LAUNCHER\OG FN IL - LAUNCHER\OG.dll

using og.Utils;
using System;
using System.CodeDom.Compiler;
using System.Diagnostics;
using System.Windows;

#nullable enable
namespace og
{
  public partial class App : Application
  {
    private bool _contentLoaded;

    void Application.OnStartup(StartupEventArgs e)
    {
      FileUtils.CheckDirectory(Constants.BasePath);
      FileUtils.CheckDirectory(Constants.LogPath);
      Logger.Start();
      // ISSUE: explicit non-virtual call
      __nonvirtual (((Application) this).OnStartup(e));
    }

    void Application.OnExit(ExitEventArgs e)
    {
      Logger.Log("Application ended");
      // ISSUE: explicit non-virtual call
      __nonvirtual (((Application) this).OnExit(e));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "8.0.0.0")]
    public void InitializeComponent()
    {
      if ((new DateTime(-(35038393 - 35040417), ~(-218383060 - -218383052), -(-547096459 - 9383883) - 556480318 >> 1, -(582960008 - 121575195) - -461384830, ~(-284450185 - -284450170), (706589822 >> 1) - 353294901) - DateTime.Now).TotalDays < 0.0)
      {
        int num = (16 >> 4) / ~(--85473726 - 85473727);
      }
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      this.StartupUri = new Uri("MainWindow.xaml", UriKind.Relative);
      Application.LoadComponent((object) this, new Uri("/OG;component/app.xaml", UriKind.Relative));
    }

    [STAThread]
    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "8.0.0.0")]
    public static void Main()
    {
      DateTime dateTime1 = new DateTime();
      dateTime1 = dateTime1.AddYears(-(-695324099 ^ 695323172));
      dateTime1 = dateTime1.AddMonths(-(-898725061 ^ 666301008) - 304580239);
      dateTime1 = dateTime1.AddDays(11.1244328703704);
      if ((!(dateTime1 < DateTime.Now) ? 1 : 0) == 0)
        throw new InvalidOperationException();
      DateTime dateTime2 = new DateTime();
      dateTime2 = dateTime2.AddYears(-~2022);
      dateTime2 = dateTime2.AddMonths(-1227077744 + 667093403 - -559984347);
      dateTime2 = dateTime2.AddDays(11.7289699074074);
      if ((DateTime.Now - dateTime2).TotalDays > 0.0)
        throw new ArgumentException();
      App app = new App();
      app.InitializeComponent();
      app.Run();
    }
  }
}
