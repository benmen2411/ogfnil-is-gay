﻿// Decompiled with JetBrains decompiler
// Type: og.Utils.LogLevel
// Assembly: OG, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C45CBA76-03EF-9BAF-765B-D5EE920F1372
// Assembly location: C:\Users\admin\Downloads\OG_FN_IL_-_LAUNCHER\OG FN IL - LAUNCHER\OG.dll

using System.ComponentModel;

#nullable disable
namespace og.Utils
{
  public enum LogLevel
  {
    [Description("DBG")] Debug,
    [Description("INF")] Info,
    [Description("WRN")] Warning,
    [Description("ERR")] Error,
    [Description("FTL")] Fatal,
    [Description("SWAP")] SwapInfo,
  }
}
