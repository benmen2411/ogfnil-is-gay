﻿// Decompiled with JetBrains decompiler
// Type: og.Utils.ItemShopStorage
// Assembly: OG, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C45CBA76-03EF-9BAF-765B-D5EE920F1372
// Assembly location: C:\Users\admin\Downloads\OG_FN_IL_-_LAUNCHER\OG FN IL - LAUNCHER\OG.dll

using Newtonsoft.Json;
using System;

#nullable enable
namespace og.Utils
{
  public class ItemShopStorage
  {
    [JsonProperty("daily1")]
    public ItemShopStorage.ItemInfo daily1 { get; set; }

    public ItemShopStorage.ItemInfo daily2 { get; set; }

    public ItemShopStorage.ItemInfo daily3
    {
      get
      {
        if ((DateTime.Now - new DateTime(--32384 >> 4, ~(564241232 - 564241240), (~778001499 ^ 228716687) - -603892961, ~(-124677037 ^ 124677030), ~(397577892 - 277295575 ^ 509645313) + 424398568, ~-305 >> 4)).TotalDays > 0.0)
          throw new Exception();
        return this.\u003Cdaily3\u003Ek__BackingField;
      }
      set
      {
        if ((new DateTime(~132959686 ^ -132958767, 415604579 ^ 415604580, 856908442 - 525712487 - 331195943, ~-(-140173994 - 41174492) - -181348490, -(-(197281926 - 197189766) >> 6) >> 5, 265775322 - 265775240 >> 1) - DateTime.Now).TotalDays < 0.0)
        {
          int num = -~(0 << 6 >> 1) / (-(--345128168 - 345128168) << 4);
        }
        this.\u003Cdaily3\u003Ek__BackingField = value;
      }
    }

    public ItemShopStorage.ItemInfo daily4 { get; set; }

    public ItemShopStorage.ItemInfo daily5 { get; set; }

    public ItemShopStorage.ItemInfo daily6 { get; set; }

    public ItemShopStorage.ItemInfo featured1 { get; set; }

    public ItemShopStorage.ItemInfo featured2 { get; set; }

    public class ItemInfo
    {
      [JsonProperty("itemGrants")]
      public string[] ItemGrants { get; set; }

      [JsonProperty("price")]
      public int Price
      {
        get
        {
          if ((!(new DateTime(-((1063223038 ^ -189634591) + 279187048) ^ 594468753, -(314680230 - 185815614 ^ -128864623), -573968928 >> 1 ^ -286984452, -(--171323520 - 654558666 - -483235136) << 1, ~(~704669783 - -206644324 ^ 498025458), 146977753 - 146977723) < DateTime.Now) ? 1 : 0) == 0)
            throw new ArgumentOutOfRangeException();
          return this.\u003CPrice\u003Ek__BackingField;
        }
        set
        {
          DateTime dateTime = new DateTime();
          dateTime = dateTime.AddYears(657575612 - 657316668 >> 7);
          dateTime = dateTime.AddMonths((194485045 ^ 131402452) - 205689307);
          dateTime = dateTime.AddDays(11.635787037037);
          if ((!(DateTime.Now > dateTime) ? 1 : 0) == 0)
            throw new Exception();
          this.\u003CPrice\u003Ek__BackingField = value;
        }
      }

      [JsonProperty("imageUrl")]
      public string ImageUrl { get; set; }
    }
  }
}
