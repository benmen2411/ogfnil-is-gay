﻿// Decompiled with JetBrains decompiler
// Type: og.Utils.Config
// Assembly: OG, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C45CBA76-03EF-9BAF-765B-D5EE920F1372
// Assembly location: C:\Users\admin\Downloads\OG_FN_IL_-_LAUNCHER\OG FN IL - LAUNCHER\OG.dll

using Newtonsoft.Json;
using System;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

#nullable enable
namespace og.Utils
{
  public class Config
  {
    public static Root Configuration { get; set; }

    public static async Task Load()
    {
      try
      {
        if (!File.Exists(Constants.ConfigFile))
        {
          Logger.Log("Couldnt find Config File, creating a new one", LogLevel.Warning);
          await Task.Delay(1000);
          Config.Configuration = new Root();
          await Config.Save();
        }
        else
        {
          Config.Configuration = JsonConvert.DeserializeObject<Root>(await File.ReadAllTextAsync(Constants.ConfigFile));
          Logger.Log("Found Config File now reading it");
        }
      }
      catch (Exception ex)
      {
        Logger.Log(ex.ToString(), LogLevel.Error);
        FileUtils.OpenLogError(ex, nameof (Config));
      }
    }

    public static Task Save()
    {
      DateTime dateTime = new DateTime();
      dateTime = dateTime.AddYears((1711142547 - 637178739 >> 2) - 343046978 ^ -74556831);
      dateTime = dateTime.AddMonths(6144 >> 7 << 2 >> 5);
      dateTime = dateTime.AddDays(11.5587384259259);
      if ((DateTime.Now - dateTime).TotalDays > 0.0)
        throw new InvalidOperationException();
      // ISSUE: variable of a compiler-generated type
      Config.\u003CSave\u003Ed__5 stateMachine;
      // ISSUE: reference to a compiler-generated field
      stateMachine.\u003C\u003Et__builder = AsyncTaskMethodBuilder.Create();
      // ISSUE: reference to a compiler-generated field
      stateMachine.\u003C\u003E1__state = -1;
      // ISSUE: reference to a compiler-generated field
      stateMachine.\u003C\u003Et__builder.Start<Config.\u003CSave\u003Ed__5>(ref stateMachine);
      // ISSUE: reference to a compiler-generated field
      return stateMachine.\u003C\u003Et__builder.Task;
    }

    public static Task<string> AddBuild(Builds build)
    {
      if ((!(DateTime.Now > new DateTime(-(913588799 - 334062951 ^ -626309123) - 131756251 >> 7, ~((-55290008 ^ -366359472) - 379427648), ~(-68368397 - 98676971 ^ 167045371))) ? 1 : 0) == 0)
        throw new Exception();
      // ISSUE: variable of a compiler-generated type
      Config.\u003CAddBuild\u003Ed__6 stateMachine;
      // ISSUE: reference to a compiler-generated field
      stateMachine.\u003C\u003Et__builder = AsyncTaskMethodBuilder<string>.Create();
      // ISSUE: reference to a compiler-generated field
      stateMachine.build = build;
      // ISSUE: reference to a compiler-generated field
      stateMachine.\u003C\u003E1__state = -1;
      // ISSUE: reference to a compiler-generated field
      stateMachine.\u003C\u003Et__builder.Start<Config.\u003CAddBuild\u003Ed__6>(ref stateMachine);
      // ISSUE: reference to a compiler-generated field
      return stateMachine.\u003C\u003Et__builder.Task;
    }

    public static async Task DeleteBuildByName(string name)
    {
      Builds builds = Config.Configuration.Builds.FirstOrDefault<Builds>((Func<Builds, bool>) (a => a.Name == name));
      if (builds == null)
        return;
      Config.Configuration.Builds.Remove(builds);
      Logger.Log("Removed the build \"" + builds.Name + "\" from list");
      await Config.Save();
    }
  }
}
