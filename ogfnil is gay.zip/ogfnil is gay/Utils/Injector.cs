﻿// Decompiled with JetBrains decompiler
// Type: og.Utils.Injector
// Assembly: OG, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C45CBA76-03EF-9BAF-765B-D5EE920F1372
// Assembly location: C:\Users\admin\Downloads\OG_FN_IL_-_LAUNCHER\OG FN IL - LAUNCHER\OG.dll

using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;

#nullable enable
namespace og.Utils
{
  public class Injector
  {
    public static void InjectDll(int processId, string path)
    {
      IntPtr hProcess = Win32.OpenProcess(1082, false, processId);
      IntPtr procAddress = Win32.GetProcAddress(Win32.GetModuleHandle("kernel32.dll"), "LoadLibraryA");
      uint num1 = (uint) ((path.Length + 1) * Marshal.SizeOf(typeof (char)));
      IntPtr num2 = Win32.VirtualAllocEx(hProcess, IntPtr.Zero, num1, 12288U, 4U);
      Win32.WriteProcessMemory(hProcess, num2, Encoding.Default.GetBytes(path), num1, out UIntPtr _);
      Win32.CreateRemoteThread(hProcess, IntPtr.Zero, 0U, procAddress, num2, 0U, IntPtr.Zero);
      DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(22, 1);
      interpolatedStringHandler.AppendLiteral("Injected Runtime into ");
      interpolatedStringHandler.AppendFormatted<int>(processId);
      Logger.Log(interpolatedStringHandler.ToStringAndClear());
      interpolatedStringHandler = new DefaultInterpolatedStringHandler(25, 1);
      interpolatedStringHandler.AppendLiteral("Injected Memoryleak into ");
      interpolatedStringHandler.AppendFormatted<int>(processId);
      Logger.Log(interpolatedStringHandler.ToStringAndClear());
    }
  }
}
