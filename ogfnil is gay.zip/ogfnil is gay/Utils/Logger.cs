﻿// Decompiled with JetBrains decompiler
// Type: og.Utils.Logger
// Assembly: OG, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C45CBA76-03EF-9BAF-765B-D5EE920F1372
// Assembly location: C:\Users\admin\Downloads\OG_FN_IL_-_LAUNCHER\OG FN IL - LAUNCHER\OG.dll

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;

#nullable enable
namespace og.Utils
{
  public static class Logger
  {
    private static TextWriter _writer;

    public static void Start()
    {
      DefaultInterpolatedStringHandler interpolatedStringHandler;
      if (File.Exists(Constants.LogFile))
      {
        List<FileInfo> list = ((IEnumerable<FileInfo>) new DirectoryInfo(Constants.LogPath).GetFiles()).OrderByDescending<FileInfo, DateTime>((Func<FileInfo, DateTime>) (a => a.LastWriteTimeUtc)).ToList<FileInfo>();
        FileInfo fileInfo1 = list.FirstOrDefault<FileInfo>();
        FileInfo fileInfo2 = list.LastOrDefault<FileInfo>();
        if (list.Count >= 20)
          fileInfo2.Delete();
        FileInfo fileInfo3 = fileInfo1;
        string fullName = fileInfo1.FullName;
        interpolatedStringHandler = new DefaultInterpolatedStringHandler(12, 1);
        interpolatedStringHandler.AppendLiteral("-backup-");
        interpolatedStringHandler.AppendFormatted<DateTime>(fileInfo1.LastWriteTimeUtc, "yyyy.MM.dd-HH.mm.ss");
        interpolatedStringHandler.AppendLiteral(".log");
        string stringAndClear = interpolatedStringHandler.ToStringAndClear();
        string destFileName = fullName.Replace(".log", stringAndClear);
        fileInfo3.MoveTo(destFileName);
      }
      Logger._writer = (TextWriter) File.CreateText(Constants.LogFile);
      Logger._writer.WriteLine("Launcher log");
      TextWriter writer = Logger._writer;
      interpolatedStringHandler = new DefaultInterpolatedStringHandler(13, 1);
      interpolatedStringHandler.AppendLiteral("# Started on ");
      interpolatedStringHandler.AppendFormatted<DateTime>(DateTime.Now);
      string stringAndClear1 = interpolatedStringHandler.ToStringAndClear();
      writer.WriteLine(stringAndClear1);
      Logger._writer.WriteLine();
      Logger._writer.Flush();
    }

    public static void Log(string msg, LogLevel level = LogLevel.Info)
    {
      MethodBase method = new StackTrace().GetFrame(1).GetMethod();
      string str1 = method.ReflectedType.Name;
      string str2 = method.Name;
      if (str2 == ".ctor")
        str2 = "Constructor";
      if (str1.Contains("Service"))
        str1 = str1.Replace("Service", "");
      if (str1.Contains('<'))
        str1 = str1.Split('<')[1].Split('>')[0];
      ConsoleColor consoleColor;
      switch (level)
      {
        case LogLevel.Debug:
          consoleColor = ConsoleColor.Cyan;
          break;
        case LogLevel.Info:
          consoleColor = ConsoleColor.Green;
          break;
        case LogLevel.Warning:
          consoleColor = ConsoleColor.DarkYellow;
          break;
        case LogLevel.Error:
          consoleColor = ConsoleColor.Red;
          break;
        case LogLevel.Fatal:
          consoleColor = ConsoleColor.DarkRed;
          break;
        case LogLevel.SwapInfo:
          consoleColor = ConsoleColor.Magenta;
          break;
        default:
          // ISSUE: reference to a compiler-generated method
          \u003CPrivateImplementationDetails\u003E.ThrowSwitchExpressionException((object) level);
          break;
      }
      Console.ForegroundColor = consoleColor;
      if (level == LogLevel.Debug)
        return;
      DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(12, 5);
      interpolatedStringHandler.AppendLiteral("[");
      interpolatedStringHandler.AppendFormatted<DateTime>(DateTime.Now);
      interpolatedStringHandler.AppendLiteral("] [Log");
      interpolatedStringHandler.AppendFormatted(str1);
      interpolatedStringHandler.AppendLiteral("::");
      interpolatedStringHandler.AppendFormatted(str2);
      interpolatedStringHandler.AppendLiteral(" ");
      interpolatedStringHandler.AppendFormatted(level.GetDescription());
      interpolatedStringHandler.AppendLiteral("] ");
      interpolatedStringHandler.AppendFormatted(msg);
      string stringAndClear = interpolatedStringHandler.ToStringAndClear();
      Console.WriteLine(stringAndClear);
      Logger._writer.WriteLine(stringAndClear);
      Logger._writer.Flush();
    }

    public static string GetDescription(this Enum value)
    {
      Type type = value.GetType();
      string name = Enum.GetName(type, (object) value);
      if (name == null)
        return (string) null;
      FieldInfo field = type.GetField(name);
      if (field == (FieldInfo) null)
        return (string) null;
      return Attribute.GetCustomAttribute((MemberInfo) field, typeof (DescriptionAttribute)) is DescriptionAttribute customAttribute ? customAttribute.Description : (string) null;
    }
  }
}
