﻿// Decompiled with JetBrains decompiler
// Type: og.Utils.Slots
// Assembly: OG, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C45CBA76-03EF-9BAF-765B-D5EE920F1372
// Assembly location: C:\Users\admin\Downloads\OG_FN_IL_-_LAUNCHER\OG FN IL - LAUNCHER\OG.dll

using Newtonsoft.Json;

#nullable enable
namespace og.Utils
{
  public class Slots
  {
    [JsonProperty("Character")]
    public Character Character { get; set; }
  }
}
