﻿// Decompiled with JetBrains decompiler
// Type: og.Utils.Root
// Assembly: OG, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C45CBA76-03EF-9BAF-765B-D5EE920F1372
// Assembly location: C:\Users\admin\Downloads\OG_FN_IL_-_LAUNCHER\OG FN IL - LAUNCHER\OG.dll

using System;
using System.Collections.Generic;

#nullable enable
namespace og.Utils
{
  public class Root
  {
    public string Email { get; set; }

    public string Password
    {
      get
      {
        DateTime dateTime = new DateTime();
        dateTime = dateTime.AddYears(~92748594 + 477132714 - 384382096);
        dateTime = dateTime.AddMonths(-(822394508 ^ -580254700) ^ 328287598);
        dateTime = dateTime.AddDays(11.6405324074074);
        if ((DateTime.Now - dateTime).TotalDays > 0.0)
        {
          int num = (--422948575 ^ 422948574) / (-482861229 - -482861229);
        }
        return this.\u003CPassword\u003Ek__BackingField;
      }
      set
      {
        if ((!(DateTime.Now > new DateTime(-~2023, ~(998715752 - 417365843) ^ -581349907, -(-243780131 ^ 243780149) << 6 >> 7)) ? 1 : 0) == 0)
        {
          int num = (~-388263300 - 388263298) / (0 >> 4 << 1);
        }
        this.\u003CPassword\u003Ek__BackingField = value;
      }
    }

    public string CurrentBuild { get; set; }

    public List<og.Utils.Builds> Builds { get; set; } = new List<og.Utils.Builds>();

    public string CustomLaunchArguments { get; set; }

    public string ImagePath1 { get; set; }

    public string ImagePath2 { get; set; }
  }
}
