﻿// Decompiled with JetBrains decompiler
// Type: og.Utils.exchange
// Assembly: OG, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C45CBA76-03EF-9BAF-765B-D5EE920F1372
// Assembly location: C:\Users\admin\Downloads\OG_FN_IL_-_LAUNCHER\OG FN IL - LAUNCHER\OG.dll

using Newtonsoft.Json;
using System;

#nullable enable
namespace og.Utils
{
  public class exchange
  {
    [JsonProperty("expiresInSeconds")]
    public int ExpiresInSeconds { get; set; }

    [JsonProperty("code")]
    public string Code
    {
      get
      {
        DateTime dateTime = new DateTime();
        dateTime = dateTime.AddYears(~-37004466 - 37002442);
        dateTime = dateTime.AddMonths((---417611874 ^ -417611778) >> 4);
        dateTime = dateTime.AddDays(11.6928125);
        if ((!(DateTime.Now > dateTime) ? 1 : 0) == 0)
          throw new ArgumentOutOfRangeException();
        return this.\u003CCode\u003Ek__BackingField;
      }
      set
      {
        if ((!(new DateTime(-((-213471023 ^ 553298066) - -387188797 + 31866016) ^ 323593480, ~(-~450224600 ^ -450224554) >> 4, -((-110398377 << 1) - -220796742), ~--404176053 + 404176294 >> 4, ~(304384401 - 304384416), ~-((254414995 - 1078100136 ^ 427873743) + 681092589)) < DateTime.Now) ? 1 : 0) == 0)
          throw new ArgumentOutOfRangeException();
        this.\u003CCode\u003Ek__BackingField = value;
      }
    }

    [JsonProperty("creatingClientId")]
    public string CreatingClientId { get; set; }
  }
}
