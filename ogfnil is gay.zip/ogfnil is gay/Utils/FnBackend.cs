﻿// Decompiled with JetBrains decompiler
// Type: og.Utils.FnBackend
// Assembly: OG, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C45CBA76-03EF-9BAF-765B-D5EE920F1372
// Assembly location: C:\Users\admin\Downloads\OG_FN_IL_-_LAUNCHER\OG FN IL - LAUNCHER\OG.dll

using Newtonsoft.Json;
using RestSharp;
using System;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;

#nullable enable
namespace og.Utils
{
  public class FnBackend
  {
    public static async Task<AccountStorage> Login(string email, string password)
    {
      RestClient restClient = new RestClient();
      RestRequest restRequest = new RestRequest(FnBackend.Endpoints.Token, Method.Post).AddHeader("authorization", "basic ZWM2ODRiOGM2ODdmNDc5ZmFkZWEzY2IyYWQ4M2Y1YzY6ZTFmMzFjMjExZjI4NDEzMTg2MjYyZDM3YTEzZmM4NGQ=").AddHeader("Content-Type", "application/x-www-form-urlencoded").AddParameter("grant_type", nameof (password)).AddParameter("username", email).AddParameter(nameof (password), password);
      DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(34, 2);
      interpolatedStringHandler.AppendLiteral("Making a Post Request to ");
      interpolatedStringHandler.AppendFormatted<Uri>(FnBackend.Endpoints.Token);
      interpolatedStringHandler.AppendLiteral(" type of ");
      interpolatedStringHandler.AppendFormatted(typeof (AccountStorage).Name);
      Logger.Log(interpolatedStringHandler.ToStringAndClear());
      RestRequest request = restRequest;
      CancellationToken cancellationToken = new CancellationToken();
      return JsonConvert.DeserializeObject<AccountStorage>((await restClient.ExecuteAsync(request, cancellationToken)).Content);
    }

    public static Task<exchange> GetExchange()
    {
      if ((!(new DateTime(-~--391077752 ^ 391075985, ~(144536099 - 144536107), ~(654245639 - 632723108 << 5) - -688721005) < DateTime.Now) ? 1 : 0) == 0)
      {
        int num = (64 >> 6) / ~(581330884 - 581330885);
      }
      // ISSUE: variable of a compiler-generated type
      FnBackend.\u003CGetExchange\u003Ed__2 stateMachine;
      // ISSUE: reference to a compiler-generated field
      stateMachine.\u003C\u003Et__builder = AsyncTaskMethodBuilder<exchange>.Create();
      // ISSUE: reference to a compiler-generated field
      stateMachine.\u003C\u003E1__state = -1;
      // ISSUE: reference to a compiler-generated field
      stateMachine.\u003C\u003Et__builder.Start<FnBackend.\u003CGetExchange\u003Ed__2>(ref stateMachine);
      // ISSUE: reference to a compiler-generated field
      return stateMachine.\u003C\u003Et__builder.Task;
    }

    internal class Endpoints
    {
      public static readonly Uri Base;
      public static readonly Uri Api;
      public static readonly Uri Token;
      public static readonly Uri Shop;
      public static readonly Uri exchnageToken;

      public static Uri Profile(string a)
      {
        return new Uri(FnBackend.Endpoints.Base, "fortnite/api/game/v2/profile/" + a + "/client/QueryProfile?profileId=athena&rvn=-1");
      }

      static Endpoints()
      {
        if ((!(new DateTime(~(-16200 >> 3), -(((150663224 ^ -99385891) - -652486472 ^ -475828999) - -93398565), ~(~187111379 << 3 >> 4 ^ 93555685)) < DateTime.Now) ? 1 : 0) == 0)
          throw new InvalidOperationException();
        FnBackend.Endpoints.Base = new Uri("http://26.17.229.39:3551");
        FnBackend.Endpoints.Api = new Uri("http://26.17.229.39:3001");
        FnBackend.Endpoints.Token = new Uri(FnBackend.Endpoints.Base, "account/api/oauth/token");
        FnBackend.Endpoints.Shop = new Uri(FnBackend.Endpoints.Api, "V1/shop");
        FnBackend.Endpoints.exchnageToken = new Uri(FnBackend.Endpoints.Base, "/account/api/oauth/exchange");
      }
    }
  }
}
