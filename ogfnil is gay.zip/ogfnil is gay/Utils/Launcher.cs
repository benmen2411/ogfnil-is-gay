﻿// Decompiled with JetBrains decompiler
// Type: og.Utils.Launcher
// Assembly: OG, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C45CBA76-03EF-9BAF-765B-D5EE920F1372
// Assembly location: C:\Users\admin\Downloads\OG_FN_IL_-_LAUNCHER\OG FN IL - LAUNCHER\OG.dll

using System;
using System.Collections;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Threading;

#nullable enable
namespace og.Utils
{
  public static class Launcher
  {
    public static async Task LaunchFortniteGame()
    {
      Logger.Log("Starting to launch fortnite");
      await DownloadUtils.DownloadNative();
      await DownloadUtils.DownloadCB();
      await DownloadUtils.DownloadMemoryleak();
      Process a1 = new Process()
      {
        StartInfo = new ProcessStartInfo()
        {
          FileName = Globals.FortniteLaucher(),
          CreateNoWindow = true
        }
      };
      a1.Start();
      DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(19, 2);
      interpolatedStringHandler.AppendLiteral("Started Process ");
      interpolatedStringHandler.AppendFormatted(Path.GetFileName(Globals.FortniteLaucher()));
      interpolatedStringHandler.AppendLiteral(" (");
      interpolatedStringHandler.AppendFormatted<int>(a1.Id);
      interpolatedStringHandler.AppendLiteral(")");
      Logger.Log(interpolatedStringHandler.ToStringAndClear());
      Launcher.SuspendProcess(a1);
      Process a2 = new Process()
      {
        StartInfo = new ProcessStartInfo()
        {
          FileName = Globals.FortniteShippingEAC(),
          Arguments = Globals.FortniteArgs(),
          CreateNoWindow = true
        }
      };
      a2.Start();
      interpolatedStringHandler = new DefaultInterpolatedStringHandler(19, 2);
      interpolatedStringHandler.AppendLiteral("Started Process ");
      interpolatedStringHandler.AppendFormatted(Path.GetFileName(Globals.FortniteLaucher()));
      interpolatedStringHandler.AppendLiteral(" (");
      interpolatedStringHandler.AppendFormatted<int>(a2.Id);
      interpolatedStringHandler.AppendLiteral(")");
      Logger.Log(interpolatedStringHandler.ToStringAndClear());
      Launcher.SuspendProcess(a2);
      Process process = new Process()
      {
        StartInfo = new ProcessStartInfo()
        {
          FileName = Globals.FortniteShipping(),
          Arguments = Globals.FortniteArgs(),
          RedirectStandardOutput = true
        }
      };
      process.Start();
      interpolatedStringHandler = new DefaultInterpolatedStringHandler(19, 2);
      interpolatedStringHandler.AppendLiteral("Started Process ");
      interpolatedStringHandler.AppendFormatted(Path.GetFileName(Globals.FortniteShipping()));
      interpolatedStringHandler.AppendLiteral(" (");
      interpolatedStringHandler.AppendFormatted<int>(process.Id);
      interpolatedStringHandler.AppendLiteral(")");
      Logger.Log(interpolatedStringHandler.ToStringAndClear());
      Injector.InjectDll(process.Id, Constants.RunTime);
      Injector.InjectDll(process.Id, Constants.MemoryLeak);
      ((DispatcherObject) Globals.MainWindowStatic).Dispatcher.Invoke<Task>((Func<Task>) (async () => { }));
      await Task.Delay(TimeSpan.FromMinutes(3.0));
      File.Delete(Constants.RunTime);
    }

    private static void SuspendProcess(Process a)
    {
      foreach (ProcessThread thread in (ReadOnlyCollectionBase) a.Threads)
        Win32.SuspendThread(Win32.OpenThread(2, false, thread.Id));
      DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(21, 2);
      interpolatedStringHandler.AppendLiteral("Supspend Process\"");
      interpolatedStringHandler.AppendFormatted(a.ProcessName);
      interpolatedStringHandler.AppendLiteral("\" (");
      interpolatedStringHandler.AppendFormatted<int>(a.Id);
      interpolatedStringHandler.AppendLiteral(")");
      Logger.Log(interpolatedStringHandler.ToStringAndClear());
    }
  }
}
