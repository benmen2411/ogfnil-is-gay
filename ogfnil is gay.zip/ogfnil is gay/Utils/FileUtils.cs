﻿// Decompiled with JetBrains decompiler
// Type: og.Utils.FileUtils
// Assembly: OG, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C45CBA76-03EF-9BAF-765B-D5EE920F1372
// Assembly location: C:\Users\admin\Downloads\OG_FN_IL_-_LAUNCHER\OG FN IL - LAUNCHER\OG.dll

using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

#nullable enable
namespace og.Utils
{
  public static class FileUtils
  {
    public static void CheckDirectory(string dir)
    {
      if (Directory.Exists(dir))
        return;
      Directory.CreateDirectory(dir);
    }

    public static string GetUnrealEngineVersion()
    {
      FileVersionInfo versionInfo = FileVersionInfo.GetVersionInfo(Globals.FortniteShipping());
      DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(2, 3);
      interpolatedStringHandler.AppendFormatted<int>(versionInfo.FileMajorPart);
      interpolatedStringHandler.AppendLiteral(".");
      interpolatedStringHandler.AppendFormatted<int>(versionInfo.FileMinorPart);
      interpolatedStringHandler.AppendLiteral(".");
      interpolatedStringHandler.AppendFormatted<int>(versionInfo.FileBuildPart);
      return interpolatedStringHandler.ToStringAndClear();
    }

    public static void OpenLogError(Exception ex, string errorTitle)
    {
      ((DispatcherObject) Globals.MainWindowStatic).Dispatcher.Invoke<Task>((Func<Task>) (async () =>
      {
        string str = "just continue\nError - " + ex.Message;
        Wpf.Ui.Controls.MessageBox messageBox = new Wpf.Ui.Controls.MessageBox()
        {
          Title = "Error - " + errorTitle,
          Content = (object) str
        };
        messageBox.ButtonLeftName = "Open Log";
        messageBox.ButtonRightName = "Close";
        messageBox.ButtonLeftClick += (RoutedEventHandler) ((a, b) => Process.Start("explorer.exe", Constants.LogFile));
        messageBox.ButtonRightClick += (RoutedEventHandler) ((a, b) => messageBox.Close());
        messageBox.Show();
      }));
    }
  }
}
