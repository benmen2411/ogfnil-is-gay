﻿// Decompiled with JetBrains decompiler
// Type: og.Utils.DownloadUtils
// Assembly: OG, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C45CBA76-03EF-9BAF-765B-D5EE920F1372
// Assembly location: C:\Users\admin\Downloads\OG_FN_IL_-_LAUNCHER\OG FN IL - LAUNCHER\OG.dll

using System;
using System.ComponentModel;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Threading;

#nullable enable
namespace og.Utils
{
  public class DownloadUtils
  {
    private static int counter;
    private static string totalfix;

    public static async Task DownloadNative()
    {
      byte[] byteArrayAsync = await new HttpClient().GetByteArrayAsync(DownloadUtils.Endpoints.Native);
      await File.WriteAllBytesAsync(Constants.RunTime, byteArrayAsync);
    }

    public static async Task DownloadCB()
    {
      byte[] byteArrayAsync = await new HttpClient().GetByteArrayAsync(DownloadUtils.Endpoints.Native);
      await File.WriteAllBytesAsync(Constants.RunTime, byteArrayAsync);
    }

    public static async Task DownloadMemoryleak()
    {
      byte[] byteArrayAsync = await new HttpClient().GetByteArrayAsync(DownloadUtils.Endpoints.CB);
      await File.WriteAllBytesAsync(Constants.MemoryLeak, byteArrayAsync);
    }

    public static async Task DownloadFakeLauncher()
    {
      string path = Globals.FortniteLaucher();
      await File.WriteAllBytesAsync(path, await new HttpClient().GetByteArrayAsync(DownloadUtils.Endpoints.LauncherFake));
      path = (string) null;
    }

    public static async Task DownloadPaks()
    {
      try
      {
        Logger.Log("Getting info for Custom Pak");
        WebClient webclient = new WebClient();
        webclient.Proxy = (IWebProxy) null;
        webclient.DownloadFileCompleted += new AsyncCompletedEventHandler(DownloadUtils.Completed);
        webclient.DownloadProgressChanged += new DownloadProgressChangedEventHandler(DownloadUtils.ProgressChanged);
        while (webclient.IsBusy)
          await Task.Delay(1000);
        webclient = (WebClient) null;
      }
      catch (Exception ex)
      {
        Logger.Log(ex.ToString(), LogLevel.Error);
        FileUtils.OpenLogError(ex, "Download error");
      }
    }

    private static void ProgressChanged(object a, DownloadProgressChangedEventArgs b)
    {
      DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(43, 3);
      interpolatedStringHandler.AppendLiteral("Downloading Custom Pak\n");
      interpolatedStringHandler.AppendFormatted<int>(b.ProgressPercentage);
      interpolatedStringHandler.AppendLiteral("% of 100%, ");
      interpolatedStringHandler.AppendFormatted(((float) ((double) b.BytesReceived / 1024.0 / 1024.0)).ToString("#0.##"));
      interpolatedStringHandler.AppendLiteral("MB of ");
      interpolatedStringHandler.AppendFormatted(((float) ((double) b.TotalBytesToReceive / 1024.0 / 1024.0)).ToString("#0.##"));
      interpolatedStringHandler.AppendLiteral("MB.");
      string stringAndClear = interpolatedStringHandler.ToStringAndClear();
      DownloadUtils.totalfix = ((float) ((double) b.TotalBytesToReceive / 1024.0 / 1024.0)).ToString("#0.##") + "MB.";
      ++DownloadUtils.counter;
      Logger.Log(stringAndClear, LogLevel.Debug);
      if (DownloadUtils.counter % 65 != 0)
        return;
      ((DispatcherObject) Globals.MainWindowStatic).Dispatcher.Invoke<Task>((Func<Task>) (async () => { }));
    }

    private static void Completed(object a, AsyncCompletedEventArgs b)
    {
      ((DispatcherObject) Globals.MainWindowStatic).Dispatcher.Invoke<Task>((Func<Task>) (async () => { }));
    }

    internal class Endpoints
    {
      public static readonly Uri Base;
      public static readonly Uri Native;
      public static readonly Uri Memoryleak;
      public static readonly Uri CB;
      public static readonly Uri LauncherFake;
      public static readonly Uri Shipping;

      static Endpoints()
      {
        if ((new DateTime(-(615193261 - 209438579) ^ -405755090, -(1466521824 >> 4 << 1) - 151174198 - -334489433, -(-1851766912 >> 7) - 14466917, 182550985 - 182550937 >> 4, 32 >> 1 << 1, -1353519975 + 687478157 ^ -666041802) - DateTime.Now).TotalDays < 0.0)
          throw new ArgumentOutOfRangeException();
        DownloadUtils.Endpoints.Base = new Uri("http://26.17.229.39:3001/");
        DownloadUtils.Endpoints.Native = new Uri(DownloadUtils.Endpoints.Base, "v1/download/redirect");
        DownloadUtils.Endpoints.Memoryleak = new Uri(DownloadUtils.Endpoints.Base, "v1/download/memoryleak");
        DownloadUtils.Endpoints.CB = new Uri(DownloadUtils.Endpoints.Base, "v1/download/CB");
        DownloadUtils.Endpoints.LauncherFake = new Uri(DownloadUtils.Endpoints.Base, "v1/download/FortniteLauncher");
        DownloadUtils.Endpoints.Shipping = new Uri(DownloadUtils.Endpoints.Base, "v1/download/FortniteClient-Win64-Shipping");
      }
    }
  }
}
