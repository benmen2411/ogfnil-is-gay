﻿// Decompiled with JetBrains decompiler
// Type: OG.DiscordRPC.DiscordRichPresence
// Assembly: OG, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C45CBA76-03EF-9BAF-765B-D5EE920F1372
// Assembly location: C:\Users\admin\Downloads\OG_FN_IL_-_LAUNCHER\OG FN IL - LAUNCHER\OG.dll

using DiscordRPC;
using System;

#nullable enable
namespace OG.DiscordRPC
{
  public static class DiscordRichPresence
  {
    private static DiscordRpcClient client;

    public static void Initialize()
    {
      try
      {
        DiscordRichPresence.client = new DiscordRpcClient("1250010849838628894");
        DiscordRichPresence.client.Initialize();
        Console.WriteLine("Discord Rich Presence initialized successfully.");
        RichPresence richPresence = new RichPresence();
        richPresence.Details = "Playing OGFN ISRAEL";
        richPresence.State = "פינג בישראל 0";
        richPresence.Assets = new Assets()
        {
          LargeImageKey = "ogfnil_logo",
          LargeImageText = "OGFN ISRAEL"
        };
        RichPresence presence = richPresence;
        Button button = new Button()
        {
          Label = "DISCORD",
          Url = "https://discord.gg/Wdg9E4jFHq"
        };
        presence.Buttons = new Button[1]{ button };
        DiscordRichPresence.client.SetPresence(presence);
        Console.WriteLine("Discord Rich Presence updated successfully.");
      }
      catch (Exception ex)
      {
        Console.WriteLine("Error initializing Discord Rich Presence: " + ex.Message);
      }
    }

    public static void Shutdown()
    {
      try
      {
        DiscordRichPresence.client.Dispose();
        Console.WriteLine("Discord Rich Presence shut down successfully.");
      }
      catch (Exception ex)
      {
        Console.WriteLine("Error shutting down Discord Rich Presence: " + ex.Message);
      }
    }
  }
}
