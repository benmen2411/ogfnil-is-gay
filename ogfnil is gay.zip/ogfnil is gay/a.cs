﻿// Decompiled with JetBrains decompiler
// Type: a
// Assembly: OG, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C45CBA76-03EF-9BAF-765B-D5EE920F1372
// Assembly location: C:\Users\admin\Downloads\OG_FN_IL_-_LAUNCHER\OG FN IL - LAUNCHER\OG.dll

using System;
using System.IO;
using System.Reflection;

#nullable disable
internal sealed class a
{
  public static string a(string a, int b)
  {
    if ((DateTime.Now - new DateTime(~(100437766 - -189919010) + 290358801, -174400001 ^ -174400008, (-1393055292 >> 1) + 696527658)).TotalDays > 0.0)
    {
      int num = ((312879106 - 592399282 >> 1) + 486257296 ^ 346497209) / (-0 >> 4);
    }
    return global::a.b.c.a(a, b);
  }

  public static string b()
  {
    char[] charArray = "\u0005 \u00110?".ToCharArray();
    int length = charArray.Length;
    while ((length -= ~-~(~47 >> 4)) >= -204580184 - -204580184 << 6)
      charArray[length] = (char) ((uint) charArray[length] ^ (uint) (--1360 >> 4));
    return new string(charArray);
  }

  private delegate string a();

  private sealed class b
  {
    private static readonly global::a.a a = new global::a.a(global::a.b);
    public static readonly global::a.b c = new global::a.b();
    private byte[] d;

    private b()
    {
      Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(global::a.b.a());
      if ((manifestResourceStream == null ? (988624207 - 628479380 ^ 107216107) - 320119631 : 164487670 - 164487670 << 1 >> 4) != 0)
        return;
      this.d = new byte[-95782577 + 95782593];
      manifestResourceStream.Read(this.d, 50978636 - 251634256 - -200655620 >> 4, this.d.Length);
    }

    public string a(string a, int b)
    {
      int length = a.Length;
      char[] charArray = a.ToCharArray();
      while ((length -= -(-(771553554 - 195232055) + 350648547 - -225672951)) >= ~(~--7 >> 3))
        charArray[length] = (char) ((uint) charArray[length] ^ ((uint) this.d[b & ~(578568978 - 578568994)] | (uint) b));
      return new string(charArray);
    }
  }
}
