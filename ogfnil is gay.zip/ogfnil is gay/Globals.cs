﻿// Decompiled with JetBrains decompiler
// Type: og.Globals
// Assembly: OG, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C45CBA76-03EF-9BAF-765B-D5EE920F1372
// Assembly location: C:\Users\admin\Downloads\OG_FN_IL_-_LAUNCHER\OG FN IL - LAUNCHER\OG.dll

using og.Utils;
using System.IO;
using System.Runtime.CompilerServices;

#nullable enable
namespace og
{
  public static class Globals
  {
    public static MainWindow MainWindowStatic { get; set; }

    public static AccountStorage AccountStorage { get; set; }

    public static Athena Athena { get; set; }

    public static exchange exchange { get; set; }

    public static string FortniteLaucher()
    {
      return Path.Combine(Config.Configuration.CurrentBuild, "FortniteGame\\Binaries\\Win64\\FortniteLauncher.exe");
    }

    public static string FortniteShipping()
    {
      return Path.Combine(Config.Configuration.CurrentBuild, "FortniteGame\\Binaries\\Win64\\FortniteClient-Win64-Shipping.exe");
    }

    public static string FortniteShippingEAC()
    {
      return Path.Combine(Config.Configuration.CurrentBuild, "FortniteGame\\Binaries\\Win64\\FortniteClient-Win64-Shipping_Eac.exe");
    }

    public static string FortniteArgs()
    {
      DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(182, 2);
      interpolatedStringHandler.AppendLiteral("-epicapp=Fortnite -epicenv=Prod -epicportal -fromfl=none -epiclocale=en-us -noeac -nobe -fltoken=fdd9g715h4i20110dd40d7d3 -AUTH_TYPE=epic -AUTH_LOGIN=");
      interpolatedStringHandler.AppendFormatted(Config.Configuration.Email);
      interpolatedStringHandler.AppendLiteral(" -AUTH_PASSWORD=");
      interpolatedStringHandler.AppendFormatted(Config.Configuration.Password);
      interpolatedStringHandler.AppendLiteral(" -skippatchcheck");
      return interpolatedStringHandler.ToStringAndClear();
    }
  }
}
