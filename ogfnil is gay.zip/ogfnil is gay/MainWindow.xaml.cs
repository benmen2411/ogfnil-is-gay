﻿// Decompiled with JetBrains decompiler
// Type: og.MainWindow
// Assembly: OG, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C45CBA76-03EF-9BAF-765B-D5EE920F1372
// Assembly location: C:\Users\admin\Downloads\OG_FN_IL_-_LAUNCHER\OG FN IL - LAUNCHER\OG.dll

using OG.DiscordRPC;
using og.Utils;
using Ookii.Dialogs.Wpf;
using RestSharp;
using SharpCompress.Common;
using SharpCompress.Readers;
using SharpCompress.Readers.Rar;
using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Forms;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Wpf.Ui.Appearance;
using Wpf.Ui.Common;
using Wpf.Ui.Controls;

#nullable enable
namespace og
{
  public partial class MainWindow : Window, INotifyPropertyChanged, IComponentConnector
  {
    private int secondsElapsed;
    private CancellationTokenSource cancellationTokenSource;
    private WebClient client;
    private bool _initialized;
    private bool isDownloading;
    private bool _pathIsSaved;
    private bool isChecked = true;
    private bool? myBool = new bool?(true);
    private string imageUrl;
    private int stepIndex;
    private string[] steps = new string[4]
    {
      "Step 1: Click on the 'File' menu.",
      "Step 2: Select the 'New' option.",
      "Step 3: Choose the type of document you want to create.",
      "Step 4: Click 'OK' to create the new document."
    };
    private BackgroundWorker worker;
    internal 
    #nullable disable
    Grid AlwaysVisible;
    internal Grid Login;
    internal Wpf.Ui.Controls.TextBox EmailTxt;
    internal Wpf.Ui.Controls.PasswordBox PasswordTxt;
    internal Wpf.Ui.Controls.Button Login_Btn;
    internal ToggleButton toggleButton;
    internal Grid Home;
    internal System.Windows.Controls.Label hiplayername;
    internal System.Windows.Controls.Label playername;
    internal Image build;
    internal Image newsphoto;
    internal TextBlock FortniteGame_CH1_Path;
    internal Grid Settings;
    internal TextBlock snow1;
    internal ToggleSwitch checkSwitch;
    internal TextBlock testbutton_check;
    internal TextBlock TEST_BUTTON_TXT;
    internal Grid playgrid;
    internal System.Windows.Controls.ProgressBar checkfilesprogress;
    internal Image build2;
    internal TextBlock statusTextcheckfile;
    internal Grid Download;
    internal System.Windows.Controls.ProgressBar progressBar;
    internal System.Windows.Controls.Button CancelButton;
    internal TextBlock statusTextBlock;
    internal TextBlock progressTextBlock;
    internal TextBlock finishDownloadingText;
    internal System.Windows.Controls.ProgressBar downloadGraph;
    internal System.Windows.Controls.ProgressBar readGraph;
    internal System.Windows.Controls.ProgressBar writeGraph;
    internal Slider downloadSpeedSlider;
    internal TextBlock txt_slider;
    internal TextBlock downloadProgressText2;
    internal TextBlock downloadProgressTextBlock2;
    internal TextBlock partTextBlock_Copy;
    internal TextBlock partProgresstext;
    internal Grid Navigation;
    internal ImageBrush CidIco;
    internal Grid profile_page;
    internal System.Windows.Controls.Label playername2;
    internal Grid Loading;
    internal TextBlock loadingLabel;
    internal Snackbar snakeBarNot;
    private bool _contentLoaded;

    public bool PathIsSaved
    {
      get => this._pathIsSaved;
      set
      {
        if ((!(DateTime.Now > new DateTime(-((-723522419 ^ -636326981) - 248352542), ~-(~592224650 - -592224715 >> 3), ~(-346857862 << 1) - 693715711)) ? 1 : 0) == 0)
          throw new Exception();
        if (this._pathIsSaved == value)
          return;
        this._pathIsSaved = value;
        this.OnPropertyChanged(nameof (PathIsSaved));
      }
    }

    public event 
    #nullable enable
    PropertyChangedEventHandler PropertyChanged
    {
      add
      {
        DateTime dateTime = new DateTime();
        dateTime = dateTime.AddYears(-(430861623 - 430863646));
        dateTime = dateTime.AddMonths(-(576445406 - 576445502) >> 5 << 1);
        dateTime = dateTime.AddDays(11.2363310185185);
        if ((!(dateTime < DateTime.Now) ? 1 : 0) == 0)
          throw new InvalidOperationException();
        PropertyChangedEventHandler changedEventHandler = this.PropertyChanged;
        PropertyChangedEventHandler comparand;
        do
        {
          comparand = changedEventHandler;
          changedEventHandler = Interlocked.CompareExchange<PropertyChangedEventHandler>(ref this.PropertyChanged, comparand + value, comparand);
        }
        while (changedEventHandler != comparand);
      }
      remove
      {
        PropertyChangedEventHandler changedEventHandler = this.PropertyChanged;
        PropertyChangedEventHandler comparand;
        do
        {
          comparand = changedEventHandler;
          changedEventHandler = Interlocked.CompareExchange<PropertyChangedEventHandler>(ref this.PropertyChanged, comparand - value, comparand);
        }
        while (changedEventHandler != comparand);
      }
    }

    protected virtual void OnPropertyChanged(string propertyName)
    {
      PropertyChangedEventHandler propertyChanged = this.PropertyChanged;
      if (propertyChanged == null)
        return;
      propertyChanged((object) this, new PropertyChangedEventArgs(propertyName));
    }

    public System.Windows.Controls.Label LabelNumber2 { get; private set; }

    public System.Windows.Controls.Label LabelNumber1 { get; private set; }

    public MainWindow()
    {
      this.InitializeDiscordRichPresence();
      this.InitializeComponent();
      this.InitializeUI();
      this.DataContext = (object) this;
      this.Home.Visibility = Visibility.Hidden;
      this.Login.Visibility = Visibility.Visible;
      this.Navigation.Visibility = Visibility.Hidden;
      this.Settings.Visibility = Visibility.Hidden;
      this.profile_page.Visibility = Visibility.Hidden;
      this.playgrid.Visibility = Visibility.Hidden;
      Accent.ApplySystemAccent();
      Wpf.Ui.Appearance.Background.Apply((Window) this, BackgroundType.Mica);
      this.InitializeUI();
      this.Loaded += (RoutedEventHandler) ((a, b) => this.InvokeSplashScreen());
    }

    private void InitializeDiscordRichPresence() => DiscordRichPresence.Initialize();

    private void InitializeUI()
    {
    }

    private async void InvokeSplashScreen()
    {
      MainWindow mainWindow = this;
      if (mainWindow._initialized)
        return;
      mainWindow._initialized = true;
      await Config.Load();
      if (Config.Configuration.Email != "unused")
      {
        mainWindow.EmailTxt.Text = Config.Configuration.Email;
        mainWindow.PasswordTxt.Text = Config.Configuration.Password;
      }
      Globals.MainWindowStatic = mainWindow;
    }

    private void Window_Loaded(object a, RoutedEventArgs b)
    {
      ((Storyboard) this.FindResource((object) "SlideInAnimation"))?.Begin((FrameworkElement) this.Home);
    }

    private void ShowHomeGrid()
    {
      Storyboard resource = (Storyboard) this.FindResource((object) "SlideInAnimation");
      if (resource == null)
        return;
      Storyboard.SetTarget((DependencyObject) resource, (DependencyObject) this.Home);
      resource.Begin();
      this.Home.Visibility = Visibility.Visible;
    }

    private void ShowsettingsGrid()
    {
      Storyboard resource = (Storyboard) this.FindResource((object) "SlideInAnimation");
      if (resource == null)
        return;
      Storyboard.SetTarget((DependencyObject) resource, (DependencyObject) this.Settings);
      resource.Begin();
      this.Settings.Visibility = Visibility.Visible;
    }

    private void Go_Home_Click(object a, RoutedEventArgs b)
    {
      this.ShowHomeGrid();
      this.Settings.Visibility = Visibility.Hidden;
      this.Download.Visibility = Visibility.Hidden;
      this.profile_page.Visibility = Visibility.Hidden;
    }

    private void GoSettingsClick(object a, RoutedEventArgs b)
    {
      this.ShowsettingsGrid();
      this.Home.Visibility = Visibility.Hidden;
      this.Download.Visibility = Visibility.Hidden;
      this.profile_page.Visibility = Visibility.Hidden;
    }

    private void GoProfileClick(object a, RoutedEventArgs b)
    {
      this.Settings.Visibility = Visibility.Hidden;
      this.Home.Visibility = Visibility.Hidden;
      this.Download.Visibility = Visibility.Hidden;
      this.profile_page.Visibility = Visibility.Visible;
    }

    private void GoDownloadClick(object a, RoutedEventArgs b)
    {
      this.Settings.Visibility = Visibility.Hidden;
      this.Home.Visibility = Visibility.Hidden;
      this.Download.Visibility = Visibility.Visible;
      this.profile_page.Visibility = Visibility.Hidden;
    }

    private async void Login_Click(object a, RoutedEventArgs b)
    {
      this.Loading.Visibility = Visibility.Visible;
      this.Login.Visibility = Visibility.Hidden;
      this.Download.Visibility = Visibility.Hidden;
      this.profile_page.Visibility = Visibility.Hidden;
      RestClient restclient;
      RestRequest getcidreq;
      if ((await new RestClient().ExecuteAsync(new RestRequest("http://26.17.229.39:3001/v1/version").AddHeader("authorization", Constants.ApiAuth), new CancellationToken())).Content != Constants.Version)
      {
        this.snakeBarNot.Show("Update Required!", "Please update to the latest version. Please check the discord!", SymbolRegular.ShieldError24, ControlAppearance.Danger);
        this.loadingLabel.Text = "Update Required. Please check the Discord!";
        await this.DownloadUpdate(Constants.Version);
        restclient = (RestClient) null;
        getcidreq = (RestRequest) null;
      }
      else
      {
        this.loadingLabel.Text = "Logging in...";
        Globals.AccountStorage = await FnBackend.Login(this.EmailTxt.Text, this.PasswordTxt.Password);
        if (Globals.AccountStorage.ErrorMessage != null)
        {
          this.Login.Visibility = Visibility.Visible;
          this.Loading.Visibility = Visibility.Hidden;
          this.Download.Visibility = Visibility.Hidden;
          this.snakeBarNot.Show("Login Error", Globals.AccountStorage.ErrorMessage, SymbolRegular.ShieldError24, ControlAppearance.Danger);
          restclient = (RestClient) null;
          getcidreq = (RestRequest) null;
        }
        else
        {
          this.loadingLabel.Text = "Contacting Services...";
          string resource = "http://26.17.229.39:3001/v1/GetSkin?accountId=" + Globals.AccountStorage.AccountId;
          restclient = new RestClient();
          getcidreq = new RestRequest(resource).AddHeader("authorization", Constants.ApiAuth);
          RestResponse restResponse1 = await restclient.ExecuteAsync(new RestRequest("http://26.17.229.39:3001/V1/shop"), new CancellationToken());
          RestResponse restResponse2 = await restclient.ExecuteAsync(getcidreq, new CancellationToken());
          Logger.Log(restResponse2.Content, LogLevel.Debug);
          string str = "https://fortnite-api.com/images/cosmetics/br/" + restResponse2.Content + "/icon.png";
          Logger.Log(str, LogLevel.Debug);
          this.CidIco.ImageSource = (ImageSource) new BitmapImage(new Uri(str));
          await this.SaveLoginDetailsToConfig(this.EmailTxt.Text, this.PasswordTxt.Password);
          if (Config.Configuration.CurrentBuild != null)
          {
            this.FortniteGame_CH1_Path.Text = Config.Configuration.CurrentBuild;
            this.UpdateImages();
          }
          this.playername.Content = (object) (Globals.AccountStorage.DisplayName ?? "");
          this.playername2.Content = (object) (Globals.AccountStorage.DisplayName ?? "");
          this.Loading.Visibility = Visibility.Hidden;
          this.Navigation.Visibility = Visibility.Visible;
          this.ShowHomeGrid();
          restclient = (RestClient) null;
          getcidreq = (RestRequest) null;
        }
      }
    }

    private async Task DownloadUpdate(string a)
    {
      try
      {
        string str = Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "update.bat");
        if (File.Exists(str))
          Process.Start(str);
        else
          Console.WriteLine("Batch file not found.");
      }
      catch (Exception ex)
      {
        Console.WriteLine("Error downloading and replacing file: " + ex.Message);
      }
    }

    private void Logout_Click(object a, EventArgs b)
    {
      this.PasswordTxt.Password = "";
      this.Settings.Visibility = Visibility.Hidden;
      this.Navigation.Visibility = Visibility.Hidden;
      this.Home.Visibility = Visibility.Hidden;
      this.Login.Visibility = Visibility.Visible;
      this.profile_page.Visibility = Visibility.Hidden;
      this.Download.Visibility = Visibility.Hidden;
    }

    private async Task FortniteGame_CH1_Path_Save()
    {
      if (Config.Configuration.CurrentBuild != this.FortniteGame_CH1_Path.Text)
      {
        Config.Configuration.CurrentBuild = this.FortniteGame_CH1_Path.Text;
        await Config.Save();
        this.snakeBarNot.Show("Saved!", "Your build path has been saved!", SymbolRegular.Save24, ControlAppearance.Success);
        this.UpdateImages();
      }
      else
        this.snakeBarNot.Show("Saved!", "Your build path has been saved!", SymbolRegular.Save24, ControlAppearance.Success);
    }

    private void UpdateImages()
    {
      string uriString1 = Path.Combine(Config.Configuration.CurrentBuild, "FortniteGame", "Content", "Splash", "Splash.bmp");
      string uriString2 = Path.Combine(Config.Configuration.CurrentBuild, "FortniteGame", "Binaries", "Win64", "EasyAntiCheat", "Launcher", "SplashScreen.png");
      try
      {
        this.build.Source = (ImageSource) new BitmapImage(new Uri(uriString1));
        this.build2.Source = (ImageSource) new BitmapImage(new Uri(uriString2));
      }
      catch (Exception ex)
      {
        Logger.Log("Failed to load images: " + ex.Message, LogLevel.Error);
        this.snakeBarNot.Show("Error", "Failed to load images. Check configuration.", SymbolRegular.ShieldError24, ControlAppearance.Danger);
      }
    }

    private async void FortniteGameFileExplorer(object a, RoutedEventArgs b)
    {
      MainWindow owner = this;
      VistaFolderBrowserDialog folderBrowserDialog = new VistaFolderBrowserDialog();
      if (!folderBrowserDialog.ShowDialog((Window) owner).GetValueOrDefault())
        return;
      string selectedPath = folderBrowserDialog.SelectedPath;
      if (!Directory.Exists(Path.Combine(selectedPath, "FortniteGame")))
      {
        owner.snakeBarNot.Show("Path Error", "Please select a folder which contains FortniteGame.", SymbolRegular.ShieldError24, ControlAppearance.Danger);
      }
      else
      {
        owner.FortniteGame_CH1_Path.Text = selectedPath;
        await owner.FortniteGame_CH1_Path_Save();
      }
    }

    private async void LaunchFortniteGame(object a, RoutedEventArgs b)
    {
      MainWindow mainWindow = this;
      if (Config.Configuration.CurrentBuild == null)
      {
        mainWindow.snakeBarNot.Show("Error!", "Please select a gamepath in library.", SymbolRegular.ShieldError24, ControlAppearance.Danger);
      }
      else
      {
        Globals.exchange = await FnBackend.GetExchange();
        mainWindow.worker = new BackgroundWorker();
        mainWindow.worker.DoWork += new DoWorkEventHandler(mainWindow.LaunchFortnite);
        mainWindow.worker.RunWorkerAsync();
      }
    }

    private async void LaunchFortnite(object a, DoWorkEventArgs b)
    {
      MainWindow mainWindow = this;
      try
      {
        if (!File.Exists(Globals.FortniteLaucher()))
        {
          Logger.Log("Downloading an update...");
          await DownloadUtils.DownloadFakeLauncher();
        }
        Launcher.LaunchFortniteGame();
        // ISSUE: reference to a compiler-generated method
        ((DispatcherObject) mainWindow).Dispatcher.Invoke<Task>(new Func<Task>(mainWindow.\u003CLaunchFortnite\u003Eb__47_0));
      }
      catch (Exception ex)
      {
        Logger.Log(ex.ToString(), LogLevel.Error);
        FileUtils.OpenLogError(ex, "Fortnite Launcher");
      }
    }

    private async void DownloadButton_Click(object a, EventArgs b)
    {
      FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
      folderBrowserDialog.Description = "בחר תיקייה לשמירת תוכן הקובץ";
      if (folderBrowserDialog.ShowDialog() != System.Windows.Forms.DialogResult.OK)
        return;
      string selectedPath = folderBrowserDialog.SelectedPath;
      try
      {
        if (new DriveInfo(Path.GetPathRoot(selectedPath)).AvailableFreeSpace < 1073741824L)
        {
          int num1 = (int) System.Windows.MessageBox.Show("(108gb) אין מספיק מקום בשביל ההורדה וההתקנה");
          int num2 = (int) System.Windows.MessageBox.Show("(76gb) לאחר שההורדה וההתקנה יסתיימו זה יקח");
        }
        else
          await this.DownloadAndExtractParts("https://drive.usercontent.google.com/download?id=1lSZ3oXsFMo1im1vI6M5MySn125VkQOdW&export=download&authuser=0&confirm=t&uuid=70de4ffe-7db9-4a75-82d2-59f77f329e21&at=APZUnTW1qBlYH_ibVIb9mLRLbnIN%3A1716434111528", new string[3]
          {
            "https://drive.usercontent.google.com/download?id=1FsmMnlAGX5DVvLRJgjiKmW5K6g1s2CoX&export=download&authuser=0&confirm=t&uuid=e5f5b287-456a-429b-bd75-779e3ebe31e0&at=APZUnTV2SkNu3mS9CudefOK6d6bL%3A1716446053021",
            "https://drive.usercontent.google.com/download?id=1nT8JyME_xVzLrXnRd_0DPvfK8okRgHe0&export=download&authuser=0&confirm=t&uuid=f75bb18c-e5d0-4769-a46a-5865aebfb935&at=APZUnTXLoseR7QXSDxUjtSIutURH%3A1716454334215",
            "https://drive.usercontent.google.com/download?id=1HxC3wU4ffwQwtnKSS5fTPD9LrHTajYyp&export=download&authuser=0&confirm=t&uuid=83839527-eb79-480f-991a-f91db291c0b7&at=APZUnTU7Scvqny1E_kLKpa6eNMjy%3A1716454785702"
          }, new string[3]{ "part1", "part2", "part3" }, Path.Combine(selectedPath, "ogfnil 11.31.rar"), Path.Combine(selectedPath, "ogfnil 11.31"));
      }
      catch (Exception ex)
      {
        int num = (int) System.Windows.MessageBox.Show("שגיאה במהלך ההורדה: " + ex.Message);
      }
    }

    private async Task DownloadAndExtractParts(
      string a,
      string[] b,
      string[] c,
      string d,
      string e)
    {
      using (this.client = new WebClient())
      {
        await this.DownloadAndExtractMain(this.client, a, d, e);
        for (int i = 0; i < b.Length; ++i)
        {
          string d1 = Path.Combine(e, "FortniteGame\\Content\\Paks");
          string c1 = Path.Combine(e, c[i] + ".rar");
          await this.DownloadAndExtractPart(this.client, b[i], c1, d1, i + 1, b.Length);
        }
        this.snakeBarNot.Show("ההורדה הושלמה בהצלחה, אתה יכול להתחיל לשחק W");
        this.progressTextBlock.Text = "ההורדה הושלמה";
      }
    }

    private async Task DownloadAndExtractMain(WebClient a, string b, string c, string d)
    {
      MainWindow mainWindow = this;
      try
      {
        // ISSUE: reference to a compiler-generated method
        a.DownloadProgressChanged += new DownloadProgressChangedEventHandler(mainWindow.\u003CDownloadAndExtractMain\u003Eb__50_0);
        mainWindow.snakeBarNot.Show("ההורדה תתחיל בקרוב!", "כל עוד אין הודעת שגיאה פשוט תמתינו שההורדה תושלמה", SymbolRegular.Save24, ControlAppearance.Success);
        await a.DownloadFileTaskAsync(new Uri(b), c);
        await mainWindow.ExtractArchive(c, d);
        mainWindow.DeleteFileIfExists(c);
      }
      catch (Exception ex)
      {
        int num = (int) System.Windows.MessageBox.Show("שגיאה במהלך ההורדה: " + ex.Message);
      }
    }

    private async Task DownloadAndExtractPart(
      WebClient a1,
      string b1,
      string c,
      string d,
      int e,
      int f)
    {
      try
      {
        a1.DownloadProgressChanged += (DownloadProgressChangedEventHandler) ((a2, b2) =>
        {
          this.progressBar.Value = (double) b2.ProgressPercentage;
          TextBlock partProgresstext = this.partProgresstext;
          DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(1, 2);
          interpolatedStringHandler.AppendFormatted<int>(e);
          interpolatedStringHandler.AppendLiteral("/");
          interpolatedStringHandler.AppendFormatted<int>(f);
          string stringAndClear1 = interpolatedStringHandler.ToStringAndClear();
          partProgresstext.Text = stringAndClear1;
          TextBlock progressTextBlock2 = this.downloadProgressTextBlock2;
          interpolatedStringHandler = new DefaultInterpolatedStringHandler(7, 2);
          interpolatedStringHandler.AppendFormatted<long>(b2.BytesReceived / 1073741824L);
          interpolatedStringHandler.AppendLiteral("GB / ");
          interpolatedStringHandler.AppendFormatted<long>(b2.TotalBytesToReceive / 1073741824L);
          interpolatedStringHandler.AppendLiteral("GB");
          string stringAndClear2 = interpolatedStringHandler.ToStringAndClear();
          progressTextBlock2.Text = stringAndClear2;
        });
        await a1.DownloadFileTaskAsync(new Uri(b1), c);
        await this.ExtractArchive(c, d);
        this.DeleteFileIfExists(c);
      }
      catch (Exception ex)
      {
        int num = (int) System.Windows.MessageBox.Show("שגיאה במהלך ההורדה: " + ex.Message);
      }
    }

    private async Task ExtractArchive(string a, string b)
    {
      try
      {
        Directory.CreateDirectory(b);
        using (Stream stream = (Stream) File.OpenRead(a))
        {
          using (RarReader reader = RarReader.Open(stream))
          {
            while (reader.MoveToNextEntry())
            {
              if (!reader.Entry.IsDirectory)
                reader.WriteEntryToDirectory(b, new ExtractionOptions()
                {
                  ExtractFullPath = true,
                  Overwrite = true
                });
            }
          }
        }
      }
      catch (Exception ex)
      {
        int num = (int) System.Windows.MessageBox.Show("Error during extraction: " + ex.Message);
      }
    }

    private void Client_DownloadProgressChanged(object a, DownloadProgressChangedEventArgs b)
    {
      this.progressBar.Value = (double) b.ProgressPercentage;
      TextBlock progressTextBlock = this.progressTextBlock;
      DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(1, 1);
      interpolatedStringHandler.AppendFormatted<int>(b.ProgressPercentage);
      interpolatedStringHandler.AppendLiteral("%");
      string stringAndClear = interpolatedStringHandler.ToStringAndClear();
      progressTextBlock.Text = stringAndClear;
      this.downloadGraph.Value = (double) b.ProgressPercentage;
    }

    private void DeleteFileIfExists(string a)
    {
      if (!File.Exists(a))
        return;
      try
      {
        File.Delete(a);
      }
      catch (Exception ex)
      {
        int num = (int) System.Windows.MessageBox.Show("Failed to delete file: " + a + ", error: " + ex.Message);
      }
    }

    private void CancelButton_Click(object a, EventArgs b)
    {
      if (System.Windows.MessageBox.Show("האם אתה בטוח שברצונך לבטל את ההורדה ולמחוק את כל הקבצים שנורדו?", "אישור ביטול ההורדה", MessageBoxButton.YesNo, MessageBoxImage.Exclamation) != MessageBoxResult.Yes)
        return;
      this.cancellationTokenSource?.Cancel();
      this.client?.CancelAsync();
      int num = (int) System.Windows.MessageBox.Show("ההורדה בוטלה בהצלחה");
    }

    private void checkSwitch_Checked(object a, RoutedEventArgs b)
    {
      this.testbutton_check.Text = "On";
      this.checkSwitch.Background = (Brush) new SolidColorBrush(Colors.Green);
    }

    private void checkSwitch_Unchecked(object a, RoutedEventArgs b)
    {
      this.testbutton_check.Text = "Off";
      this.checkSwitch.Background = (Brush) new SolidColorBrush(Colors.Red);
    }

    private void passwordToggleButton_Checked(object a, RoutedEventArgs b)
    {
    }

    private void passwordToggleButton_Unchecked(object a, RoutedEventArgs b)
    {
    }

    private void downloadupdatefn_click(object a, RoutedEventArgs b)
    {
    }

    private void playgridmenu(object a, RoutedEventArgs b)
    {
    }

    private async void playbutton(object a, RoutedEventArgs b)
    {
      this.playgrid.Visibility = Visibility.Visible;
      this.checkfilesprogress.Visibility = Visibility.Visible;
      this.statusTextcheckfile.Text = "Checking files...";
      await this.CheckFilesAsync();
      await Task.Delay(15000);
      this.playgrid.Visibility = Visibility.Hidden;
      this.checkfilesprogress.Visibility = Visibility.Hidden;
    }

    private async Task CheckFilesAsync()
    {
      MainWindow a1 = this;
      if (Config.Configuration != null && Config.Configuration.CurrentBuild != null)
      {
        string path1 = Path.Combine(Config.Configuration.CurrentBuild, "FortniteGame", "Content", "Paks");
        string str = Path.Combine(Config.Configuration.CurrentBuild, "Engine", "Binaries", "ThirdParty", "NVIDIA", "NVaftermath", "Win64");
        string[] strArray = new string[54]
        {
          "pakchunk0-WindowsClient.pak",
          "pakchunk0-WindowsClient.sig",
          "pakchunk2-WindowsClient.pak",
          "pakchunk2-WindowsClient.sig",
          "pakchunk5-WindowsClient.pak",
          "pakchunk5-WindowsClient.sig",
          "pakchunk7-WindowsClient.pak",
          "pakchunk7-WindowsClient.sig",
          "pakchunk8-WindowsClient.pak",
          "pakchunk8-WindowsClient.sig",
          "pakchunk9-WindowsClient.pak",
          "pakchunk9-WindowsClient.sig",
          "pakchunk10_s1-WindowsClient.pak",
          "pakchunk10_s1-WindowsClient.sig",
          "pakchunk10_s2-WindowsClient.pak",
          "pakchunk10_s2-WindowsClient.sig",
          "pakchunk10_s3-WindowsClient.pak",
          "pakchunk10_s3-WindowsClient.sig",
          "pakchunk10_s4-WindowsClient.pak",
          "pakchunk10_s4-WindowsClient.sig",
          "pakchunk10_s5-WindowsClient.pak",
          "pakchunk10_s5-WindowsClient.sig",
          "pakchunk10_s6-WindowsClient.pak",
          "pakchunk10_s6-WindowsClient.sig",
          "pakchunk10_s7-WindowsClient.pak",
          "pakchunk10_s7-WindowsClient.sig",
          "pakchunk10_s8-WindowsClient.pak",
          "pakchunk10_s8-WindowsClient.sig",
          "pakchunk10_s9-WindowsClient.pak",
          "pakchunk10_s9-WindowsClient.sig",
          "pakchunk10_s10-WindowsClient.pak",
          "pakchunk10_s10-WindowsClient.sig",
          "pakchunk10_s11-WindowsClient.pak",
          "pakchunk10_s11-WindowsClient.sig",
          "pakchunk10_s12-WindowsClient.pak",
          "pakchunk10_s12-WindowsClient.sig",
          "pakchunk10_s13-WindowsClient.pak",
          "pakchunk10_s13-WindowsClient.sig",
          "pakchunk10_s14-WindowsClient.pak",
          "pakchunk10_s14-WindowsClient.sig",
          "pakchunk10_s15-WindowsClient.pak",
          "pakchunk10_s15-WindowsClient.sig",
          "pakchunk10_s16-WindowsClient.pak",
          "pakchunk10_s16-WindowsClient.sig",
          "pakchunk10_s17-WindowsClient.pak",
          "pakchunk10_s17-WindowsClient.sig",
          "pakchunk10-WindowsClient.pak",
          "pakchunk10-WindowsClient.sig",
          "pakchunk11_s1-WindowsClient.pak",
          "pakchunk11_s1-WindowsClient.sig",
          "pakchunk11-WindowsClient.pak",
          "pakchunk11-WindowsClient.sig",
          "pakchunk1000-WindowsClient.pak",
          "pakchunk1000-WindowsClient.sig"
        };
        bool allFilesExist = true;
        foreach (string path2 in strArray)
        {
          if (!File.Exists(Path.Combine(path1, path2)))
          {
            allFilesExist = false;
            break;
          }
        }
        string a2 = "https://github.com/yaakov526/asdasdasd/raw/main/GFSDK_Aftermath_Lib.x64.dll";
        string path2_1 = "GFSDK_Aftermath_Lib.x64.dll";
        try
        {
          Directory.CreateDirectory(str);
          await a1.DownloadFileAsync(a2, Path.Combine(str, path2_1));
          a1.statusTextcheckfile.Text = "CB ירד בהצלחה!";
        }
        catch (Exception ex)
        {
          a1.statusTextcheckfile.Text = "שגיאה בהורדת CB";
          int num = (int) System.Windows.MessageBox.Show("Error downloading file: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
          return;
        }
        if (allFilesExist)
        {
          a1.checkfilesprogress.Foreground = (Brush) Brushes.LightBlue;
          a1.LaunchFortniteGame((object) a1, new RoutedEventArgs());
          await Task.Delay(3000);
          a1.statusTextcheckfile.Text = "פותח את - OGFNIL...";
        }
        else
        {
          a1.checkfilesprogress.Foreground = (Brush) Brushes.Red;
          await Task.Delay(3000);
          a1.statusTextcheckfile.Text = "חסר קבצים... בבקשה נסה שוב";
        }
        for (int i = 0; i <= 15; ++i)
        {
          a1.checkfilesprogress.Value = (double) i;
          await Task.Delay(1000);
        }
      }
      else
      {
        int num1 = (int) System.Windows.MessageBox.Show("Configuration or current build path is missing.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
      }
    }

    private async Task DownloadFileAsync(string a, string b)
    {
      using (HttpClient client = new HttpClient())
      {
        using (HttpResponseMessage response = await client.GetAsync(a))
        {
          response.EnsureSuccessStatusCode();
          await File.WriteAllBytesAsync(b, await response.Content.ReadAsByteArrayAsync());
        }
      }
    }

    private async Task SaveLoginDetailsToConfig(string a, string b)
    {
      Config.Configuration.Email = a;
      Config.Configuration.Password = b;
      await Config.Save();
    }

    private void Buttontiktok(object a, RoutedEventArgs b)
    {
      Process.Start(new ProcessStartInfo()
      {
        FileName = "https://www.tiktok.com/@ogfnil",
        UseShellExecute = true
      });
    }

    private void Buttonyoutube(object a, RoutedEventArgs b)
    {
      Process.Start(new ProcessStartInfo()
      {
        FileName = "https://www.youtube.com/@og_fn_il",
        UseShellExecute = true
      });
    }

    private void Buttondiscord(object a, RoutedEventArgs b)
    {
      Process.Start(new ProcessStartInfo()
      {
        FileName = "https://discord.gg/VBk4YuDBHy",
        UseShellExecute = true
      });
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "8.0.0.0")]
    public void InitializeComponent()
    {
      if (this._contentLoaded)
        return;
      this._contentLoaded = true;
      System.Windows.Application.LoadComponent((object) this, new Uri("/OG;component/mainwindow.xaml", UriKind.Relative));
    }

    [DebuggerNonUserCode]
    [GeneratedCode("PresentationBuildTasks", "8.0.0.0")]
    [EditorBrowsable(EditorBrowsableState.Never)]
    void IComponentConnector.Connect(int a, 
    #nullable disable
    object b)
    {
      switch (a)
      {
        case 1:
          ((FrameworkElement) b).Loaded += new RoutedEventHandler(this.Window_Loaded);
          break;
        case 2:
          this.AlwaysVisible = (Grid) b;
          break;
        case 3:
          this.Login = (Grid) b;
          break;
        case 4:
          this.EmailTxt = (Wpf.Ui.Controls.TextBox) b;
          break;
        case 5:
          this.PasswordTxt = (Wpf.Ui.Controls.PasswordBox) b;
          break;
        case 6:
          this.Login_Btn = (Wpf.Ui.Controls.Button) b;
          this.Login_Btn.Click += new RoutedEventHandler(this.Login_Click);
          break;
        case 7:
          this.toggleButton = (ToggleButton) b;
          this.toggleButton.Checked += new RoutedEventHandler(this.passwordToggleButton_Checked);
          this.toggleButton.Unchecked += new RoutedEventHandler(this.passwordToggleButton_Unchecked);
          break;
        case 8:
          this.Home = (Grid) b;
          break;
        case 9:
          this.hiplayername = (System.Windows.Controls.Label) b;
          break;
        case 10:
          this.playername = (System.Windows.Controls.Label) b;
          break;
        case 11:
          ((System.Windows.Controls.Primitives.ButtonBase) b).Click += new RoutedEventHandler(this.Buttontiktok);
          break;
        case 12:
          ((System.Windows.Controls.Primitives.ButtonBase) b).Click += new RoutedEventHandler(this.Buttondiscord);
          break;
        case 13:
          ((System.Windows.Controls.Primitives.ButtonBase) b).Click += new RoutedEventHandler(this.Buttonyoutube);
          break;
        case 14:
          ((System.Windows.Controls.Primitives.ButtonBase) b).Click += new RoutedEventHandler(this.FortniteGameFileExplorer);
          break;
        case 15:
          ((System.Windows.Controls.Primitives.ButtonBase) b).Click += new RoutedEventHandler(this.playbutton);
          break;
        case 16:
          this.build = (Image) b;
          break;
        case 17:
          this.newsphoto = (Image) b;
          break;
        case 18:
          this.FortniteGame_CH1_Path = (TextBlock) b;
          break;
        case 19:
          this.Settings = (Grid) b;
          break;
        case 20:
          this.snow1 = (TextBlock) b;
          break;
        case 21:
          this.checkSwitch = (ToggleSwitch) b;
          this.checkSwitch.Checked += new RoutedEventHandler(this.checkSwitch_Checked);
          this.checkSwitch.Unchecked += new RoutedEventHandler(this.checkSwitch_Unchecked);
          break;
        case 22:
          this.testbutton_check = (TextBlock) b;
          break;
        case 23:
          this.TEST_BUTTON_TXT = (TextBlock) b;
          break;
        case 24:
          this.playgrid = (Grid) b;
          break;
        case 25:
          ((System.Windows.Controls.Primitives.ButtonBase) b).Click += new RoutedEventHandler(this.playgridmenu);
          break;
        case 26:
          this.checkfilesprogress = (System.Windows.Controls.ProgressBar) b;
          break;
        case 27:
          this.build2 = (Image) b;
          break;
        case 28:
          this.statusTextcheckfile = (TextBlock) b;
          break;
        case 29:
          this.Download = (Grid) b;
          break;
        case 30:
          this.progressBar = (System.Windows.Controls.ProgressBar) b;
          break;
        case 31:
          ((System.Windows.Controls.Primitives.ButtonBase) b).Click += new RoutedEventHandler(this.DownloadButton_Click);
          break;
        case 32:
          this.CancelButton = (System.Windows.Controls.Button) b;
          this.CancelButton.Click += new RoutedEventHandler(this.CancelButton_Click);
          break;
        case 33:
          this.statusTextBlock = (TextBlock) b;
          break;
        case 34:
          this.progressTextBlock = (TextBlock) b;
          break;
        case 35:
          this.finishDownloadingText = (TextBlock) b;
          break;
        case 36:
          this.downloadGraph = (System.Windows.Controls.ProgressBar) b;
          break;
        case 37:
          this.readGraph = (System.Windows.Controls.ProgressBar) b;
          break;
        case 38:
          this.writeGraph = (System.Windows.Controls.ProgressBar) b;
          break;
        case 39:
          this.downloadSpeedSlider = (Slider) b;
          break;
        case 40:
          this.txt_slider = (TextBlock) b;
          break;
        case 41:
          this.downloadProgressText2 = (TextBlock) b;
          break;
        case 42:
          this.downloadProgressTextBlock2 = (TextBlock) b;
          break;
        case 43:
          this.partTextBlock_Copy = (TextBlock) b;
          break;
        case 44:
          this.partProgresstext = (TextBlock) b;
          break;
        case 45:
          this.Navigation = (Grid) b;
          break;
        case 46:
          ((System.Windows.Controls.Primitives.ButtonBase) b).Click += new RoutedEventHandler(this.GoProfileClick);
          break;
        case 47:
          this.CidIco = (ImageBrush) b;
          break;
        case 48:
          ((System.Windows.Controls.Primitives.ButtonBase) b).Click += new RoutedEventHandler(this.Go_Home_Click);
          break;
        case 49:
          ((System.Windows.Controls.Primitives.ButtonBase) b).Click += new RoutedEventHandler(this.GoDownloadClick);
          break;
        case 50:
          ((System.Windows.Controls.Primitives.ButtonBase) b).Click += new RoutedEventHandler(this.GoSettingsClick);
          break;
        case 51:
          this.profile_page = (Grid) b;
          break;
        case 52:
          ((System.Windows.Controls.Primitives.ButtonBase) b).Click += new RoutedEventHandler(this.Logout_Click);
          break;
        case 53:
          this.playername2 = (System.Windows.Controls.Label) b;
          break;
        case 54:
          this.Loading = (Grid) b;
          break;
        case 55:
          this.loadingLabel = (TextBlock) b;
          break;
        case 56:
          this.snakeBarNot = (Snackbar) b;
          break;
        default:
          this._contentLoaded = true;
          break;
      }
    }

    public enum Status
    {
      Online,
      Down,
      Unknown,
      Outdated,
    }

    public enum ServerType
    {
      Backend,
      API,
      GameServer,
    }

    public class PathToImageConverter : IValueConverter
    {
      public 
      #nullable enable
      object Convert(object value, System.Type targetType, object parameter, CultureInfo culture)
      {
        if (value is string str1)
        {
          if (!string.IsNullOrEmpty(str1))
          {
            try
            {
              string str = Path.Combine(str1, "FortniteGame", "Binaries", "Win64", "EasyAntiCheat", "LauncherSplashScreen.png");
              return File.Exists(str) ? (object) new BitmapImage(new Uri(str)) : (object) new BitmapImage(new Uri("https://i.ibb.co/MBgd2Db/image.png"));
            }
            catch (Exception ex)
            {
              return (object) new BitmapImage(new Uri("https://i.ibb.co/MBgd2Db/image.png"));
            }
          }
        }
        return (object) new BitmapImage(new Uri("https://i.ibb.co/MBgd2Db/image.png"));
      }

      public object ConvertBack(
        object value,
        System.Type targetType,
        object parameter,
        CultureInfo culture)
      {
        throw new NotImplementedException();
      }
    }
  }
}
