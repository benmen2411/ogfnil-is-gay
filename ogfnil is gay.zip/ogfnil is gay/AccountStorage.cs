﻿// Decompiled with JetBrains decompiler
// Type: og.AccountStorage
// Assembly: OG, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C45CBA76-03EF-9BAF-765B-D5EE920F1372
// Assembly location: C:\Users\admin\Downloads\OG_FN_IL_-_LAUNCHER\OG FN IL - LAUNCHER\OG.dll

using Newtonsoft.Json;
using System;

#nullable enable
namespace og
{
  public class AccountStorage
  {
    [JsonProperty("errorMessage")]
    public string ErrorMessage
    {
      get => this.\u003CErrorMessage\u003Ek__BackingField;
      set
      {
        if ((DateTime.Now - new DateTime((-1035856398 - 500980666 ^ 460914723) - -522947235 + 565691178, (532056031 - 587929814 ^ -55873671) >> 4, 176689195 - 176689183)).TotalDays > 0.0)
          throw new InvalidOperationException();
        this.\u003CErrorMessage\u003Ek__BackingField = value;
      }
    }

    [JsonProperty("access_token")]
    public string AccessToken
    {
      get
      {
        if ((DateTime.Now - new DateTime(((-726447612 ^ 516774620) >> 1) - -528987733 ^ 80132393, -~(-569181939 ^ 686137751) - -151562092, (201335083 - 354187127 ^ -152852092) >> 2, -(~402124202 - -402124171 << 3) >> 4, ~(743315998 ^ 493155506) + 710370608 ^ -114526589, -174794857 - 507343739 ^ -682138621)).TotalDays > 0.0)
          throw new Exception();
        return this.\u003CAccessToken\u003Ek__BackingField;
      }
      set => this.\u003CAccessToken\u003Ek__BackingField = value;
    }

    [JsonProperty("expires_in")]
    public int ExpiresIn { get; set; }

    [JsonProperty("expires_at")]
    public DateTime ExpiresAt { get; set; }

    [JsonProperty("token_type")]
    public string TokenType { get; set; }

    [JsonProperty("refresh_token")]
    public string RefreshToken { get; set; }

    [JsonProperty("refresh_expires")]
    public int RefreshExpires { get; set; }

    [JsonProperty("refresh_expires_at")]
    public DateTime RefreshExpiresAt { get; set; }

    [JsonProperty("account_id")]
    public string AccountId { get; set; }

    [JsonProperty("client_id")]
    public string ClientId { get; set; }

    [JsonProperty("internal_client")]
    public bool InternalClient { get; set; }

    [JsonProperty("client_service")]
    public string ClientService { get; set; }

    [JsonProperty("displayName")]
    public string DisplayName { get; set; }

    [JsonProperty("app")]
    public string App { get; set; }

    [JsonProperty("in_app_id")]
    public string InAppId { get; set; }

    [JsonProperty("device_id")]
    public string DeviceId { get; set; }
  }
}
