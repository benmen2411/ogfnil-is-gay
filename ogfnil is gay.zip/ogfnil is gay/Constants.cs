﻿// Decompiled with JetBrains decompiler
// Type: og.Constants
// Assembly: OG, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C45CBA76-03EF-9BAF-765B-D5EE920F1372
// Assembly location: C:\Users\admin\Downloads\OG_FN_IL_-_LAUNCHER\OG FN IL - LAUNCHER\OG.dll

using System;
using System.IO;

#nullable enable
namespace og
{
  public static class Constants
  {
    public static readonly string BasePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "OGFNIL-Launcher-Config\\");
    public static readonly string BaseLogs = Path.Combine(Constants.BasePath, "Advanced");
    public static readonly string LogPath = Path.Combine(Constants.BaseLogs, "Logs");
    public static readonly string LogFile = Path.Combine(Constants.LogPath, "OG-Launcher.log");
    public static readonly string ConfigFile = Path.Combine(Constants.BasePath, "config.OGLauncher");
    public static readonly string RunTime = Path.Combine(Constants.BasePath, "OG-Runtime.dll");
    public static readonly string MemoryLeak = Path.Combine(Constants.BasePath, "memoryleak.dll");
    public static readonly string ApiAuth = "Bearer bdy32rw3dbui3odnoi3ndidfbewifbvowebi3h34uigweo8u3";
    public static readonly string Version = "3.0.0";
  }
}
